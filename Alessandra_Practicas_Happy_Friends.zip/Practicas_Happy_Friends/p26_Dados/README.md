# PRÁCTICA 23B - Dados

1. Crea 6 documentos html cada uno con dado que muestre un lado del dado (1-6), utilizando flex únicamente para posicionar los puntos.