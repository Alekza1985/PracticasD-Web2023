
    const gateteContainer = document.querySelector('.grid-gatetes');

    //funcion para enviar gato 3
    //function sendGateteThree(gatetesObj){
    // return fetch('backend/jsonReceive.php' 
        //Method: 'POST';
        //body: JSON.stringify(gateteObject)
    //})
    //.then(response => response.json())
    //.then(data=> {
        //const jsonRecibido = JSON.parse(data)
        //document.body.innerHTML += jsonRecibido.id
        // })


    //Funcion para crear todos los gatos 
    function createGatetes(gatetesObj){
        console.log(gatetesObj)
        gatetesObj.forEach(gateteItem => {
            const gatete = document.createElement('img');
            gatete.src = gateteItem.url; // Acceder al URL del elemento actual
            gateteContainer.appendChild(gatete); 
        }) //toda esta forma abreviada es para cuando hay un parametro y una sola llamada

        //sendGateteThree(gatetesObj[2])
    }


    fetch('https://api.thecatapi.com/v1/images/search?api_key=live_TtJnbXXHsx432bsyUTdd3wdZWFkCAeV1UtthIiNSmMGbA6rsZwdBYxQ1ldzRqqvI&limit=20')
    // espero a que el recurso este disposnible y entonces...
        .then(response => response.json())
        .then(data => createGatetes(data))
           



