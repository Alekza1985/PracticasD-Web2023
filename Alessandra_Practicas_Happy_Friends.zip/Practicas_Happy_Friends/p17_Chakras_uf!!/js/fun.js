
const chakras = document.querySelectorAll(".chakra");

chakras.forEach(chakra => {
  chakra.addEventListener("click", function () {
    
    // Obtiene el nombre del color del chakra
    const color = this.classList[1]; 

    // Encuentra el elemento de audio correspondiente
    const sound = document.getElementById("sound_" + color); 
    
    if (sound.paused) {
      // Reproduce la música si está en pausa
      sound.play(); 

    } else {
      // Pausa la música si se está reproduciendo
      sound.pause(); 
    }
  });
});

  



