1. Clona PIXEL PERFECT la web oficial de NIKE desde el header hasta el video principal, sin animaciones.

2. Investiga la tipografía utilizada y otros elementos con el inspector de chrome

3. La web está en esta url -> https://www.nike.com/es/   

