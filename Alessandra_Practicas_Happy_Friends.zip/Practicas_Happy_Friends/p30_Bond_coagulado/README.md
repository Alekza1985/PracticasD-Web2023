# PRÁCTICA 25 - James Bond

1. Crear intro de James bond de las películas antiguas
