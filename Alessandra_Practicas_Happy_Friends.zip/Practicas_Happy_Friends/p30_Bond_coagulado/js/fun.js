    document.addEventListener('DOMContentLoaded', function () {
        const button = document.getElementById('startButton');
        const circle = document.querySelector('.bond__circle');
        const photo = document.querySelector('.bond__photo');
        let bondThemeAudioSrc = 'audio/Bond_Theme.mp3'; // Ruta del tema de James Bond

        button.addEventListener('click', function () {
            circle.style.animationPlayState = 'running'; // Inicia la animación al hacer clic en el botón

            const bondThemeAudio = new Audio(bondThemeAudioSrc); // Crea el objeto Audio con la ruta dinámica
            bondThemeAudio.play(); // Inicia la reproducción del audio Bond_Theme.mp3
        });
    });
