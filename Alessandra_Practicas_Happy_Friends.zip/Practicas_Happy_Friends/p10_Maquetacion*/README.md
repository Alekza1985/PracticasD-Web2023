# P10 - MAQUETACIÓN

- Traslada a código las 3 imágenes que hay en la carpeta img.

	1. Maquetar pensando en bloques.
	2. Maquetar pensando cual es la forma más óptima si en horizontal o en vertical.
	3. Maquetar planteando una buena estrategia de clases buscando estilos comunes/distintos en los distintos cuadrados. 