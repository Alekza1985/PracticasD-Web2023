1. Crea un grid centrado en el viewport como el que ves en la imagen adjunta.
2. El grid debe ser responsive y adaptarse al redimensionado de pantalla.