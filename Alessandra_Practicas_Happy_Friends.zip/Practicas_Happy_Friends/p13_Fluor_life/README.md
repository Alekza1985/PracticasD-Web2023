1. Traslada a código (maquetación) la foto adjunta en la carpeta img sin utilizar clases ni ids. **Sólo etiquetas**

2. Implementa que cuando se haga hover sobre los bloques de colores se pongan de color blanco.

3. Implementa que cuando se haga hover sobre el título se ponga de color fluor:
    be fluor -> magenta
    be lightful -> amarillo
    be cool -> cyan

4. Haz que la página web se adapte al ancho de pantalla.

5. Haz que el cursor pase a ser una mano en los elementos cambiantes (barras , nombres) hover

6. Crea efecto de ráfaga de forma que las barras cambien de color secuencialmente una detrás de otra y vuelvan a su color original al cargar la página