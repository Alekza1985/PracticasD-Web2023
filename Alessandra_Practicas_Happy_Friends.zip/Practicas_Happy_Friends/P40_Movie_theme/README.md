1. Crea una web que muestre el ranking con los actores/actrices del fichero json adjunto.

2. Cada item del ranking deberá mostrar:
    - Nombre
    - nombre alternativo
    - Puntuación
    - Object ID

3. Los nombres no disponibles deberán mostrar "no disponible", en vez de null.

4. Los items deberán tener colores según su puntuación: 
    - por encima de 3000 -> gama de color específica
    - de 2000 a 3000 -> gama de color específica
    - de 1000 a 2000-> gama de color específica
    - de 500 a 1000 -> gama de color específica
    - de 0 a 500 -> gama de color específica