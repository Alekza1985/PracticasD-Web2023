1. Trasladar a código la imagen adjunta.
2. Pixel Perfect