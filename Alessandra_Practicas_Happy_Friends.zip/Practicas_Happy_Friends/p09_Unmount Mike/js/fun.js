
const unmountMikeBtn = document.getElementById('unmountMikeBtn');

function refresh() {
    location.reload();
}

// Agregar el evento click al botón
if (unmountMikeBtn) {
    unmountMikeBtn.addEventListener('click', refresh);
}
