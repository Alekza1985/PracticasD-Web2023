1. Traslada a código el diseño que se muestra en el archivo adjunto genius.png.
2. Haz que sea responsive.