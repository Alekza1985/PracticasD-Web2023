# PEX 1 - WHATSAPP

1. Maqueta la pantalla principal de whatsapp creando círculos con DIV o SPAN en vez de iconos/imágenes.
2. Utiliza la imagen adjunta como guía.