


1. Crea una función que pinte una circunferencia en el centro de la pantalla del diámetro especificado por parámetro de la misma (en px).

2. Crea una función que cuando el usuario haga click en un botón simule el lanzamiento de una moneda al aire y devuelva cara o cruz en un div al lado del botón. Cuando el usuario haya hecho 3 lanzamientos, que la función se inactive y en el div se muetre " No tientes a tu suerte, amigo".


3. Crea 3 funciones:
    - Nombre: que reciba un nombre lo ponga en mayúsculas y devuelva el resultado;
    - Apellidos: que reciba los apellidos los ponga en mayúsculas y devuelva el resultado;
    - Saludo: que llame a las otras dos y les pase por parámetro nombre y apellidos al llamarlas
    - Que la función pinte el saludo en el body automáticamente al inicializar la web


4. Crea una función que dado un elemento dom permita: 
    - borrarlo
    - copiarlo debajo
    - insertar un texto dentro del elemento

    - dependiendo de los parámetros que se le pasen función. 
        - Ejemplo: domManipulator(obj, borrar) -> borra
        - Ejemplo: domManipulator(obj, copiar) -> copia

    - Crea botones HTML que lancen la función


5. Crea un objeto que tenga un método que permita concatenar los valores de todas sus propiedades (sin harcodear).


6. Crea un sistema de funciones que calcule el ancho y alto de la pantalla y cree N divs (por parámetro) que rellenen toda la pantalla y que cada uno de ellos tenga un color de fondo progresivo del arcoiris desde rojo a violeta.
