

const audioTrack = new Audio('audio/bamboleo.mp3');
const controls = document.querySelector('.container__music--player--left--buttons');
const stopButton = document.querySelector('.button__stop img');
const playButton = document.querySelector('.button__play img');
const fastFowardButton = document.querySelector('.button__fast--foward img');
const timeDisplay = document.querySelector('.container__music--player--right--time h3');


//Funcion principal que gestiona el audio del sistema

function audioEngine(e) {

   e.target.dataset.value === "stop" && stopEngine();

   e.target.dataset.value === "play" && playEngine();

   e.target.dataset.value === "fast-foward" && fastFowardEngine();
}

//Funcion que gestiona cuando se hace click en boton play.

function playEngine() {
    audioTrack.play();
    playEngineImage();
}

function playEngineImage() {
    playButton.src = 'svg/play-on.svg';
    stopButton.src = 'svg/stop-stop.svg';
}

//Funcion que gestiona cuando se hace click en boton stop.

function stopEngine() {
    audioTrack.pause();
    audioTrack.currentTime = 0;
    stopEngineImage();
}

function stopEngineImage(){
    stopButton.src= 'svg/stop-play.svg';
    playButton.src = 'svg/play-off.svg';
}

function fastFowardEngine() {
audioTrack.play()
audioTrack.currentTime += 5;
// Cambia la imagen a "play-forward-on.svg" instantáneamente al hacer clic
fastFowardButton.src = 'svg/play-forward-on.svg'; 

// Cambia la imagen de vuelta a "play-forward-off.svg" después de 1 segundo (100 ms)
setTimeout(function() {
    fastFowardButton.src = 'svg/play-forward-off.svg'; 
}, 100)};


controls.addEventListener('click', audioEngine);



let isPlaying = false;
let currentTime = 0;
let duration = 0;
let timerInterval;

audioTrack.addEventListener('loadedmetadata', () => {
duration = audioTrack.duration;
updateTimer();
});

function updateTimer() {
timerInterval = setInterval(() => {
    currentTime = audioTrack.currentTime;
    const remainingTime = duration - currentTime;
    
    // Convertir tiempo a formato mm:ss
    const remainingMinutes = Math.floor(remainingTime / 60);
    const remainingSeconds = Math.floor(remainingTime % 60);
    const formattedTime = `${remainingMinutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    
    timeDisplay.textContent = formattedTime;

    if (currentTime >= duration) {
        clearInterval(timerInterval);
        timeDisplay.textContent = '0:00';
    }
}, 1000);
}

function audioEngine(e) {
if (e.target.dataset.value === "stop") {
    stopEngine();
} else if (e.target.dataset.value === "play") {
    playEngine();
} else if (e.target.dataset.value === "fast-foward") {
    fastFowardEngine();
}
}

function playEngine() {
if (!isPlaying) {
    audioTrack.play();
    playEngineImage();
    updateTimer();
    isPlaying = true;
}
}

function stopEngine() {
audioTrack.pause();
audioTrack.currentTime = 0;
stopEngineImage();
clearInterval(timerInterval);
isPlaying = false;
timeDisplay.textContent = '0:00';
}

