1. Crea un reproductor de audio con JS HTML y CSS
    - El audio track carga por defecto al cargar la página;
    - botón play, stop y rewind
    - los botones se deben iluminar cuando estén pulsados: play/stop todo el rato, rewind solo al hacer mousedown