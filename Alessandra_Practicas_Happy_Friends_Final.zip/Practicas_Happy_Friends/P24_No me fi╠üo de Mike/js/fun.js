//Captura de Elementos

const startBtn = document.querySelector ('.no-me-fio__start');
const subItems = document.querySelectorAll ('.no-me-fio__item');

//Creacion del Evento sobre la variable capturada

startBtn.addEventListener ('click', moveItems);

//Declaro funcion que va a suceder cuando haga click en el boton. 

function moveItems () {

    subItems.forEach (item => {
        item.classList.toggle('play');
    })
}