# NO ME FÍO DE MIKE

1. Crea una aplicación que permita descubrir los 4 pilares de la confianza:
    - Respeto
    - Verdad
    - Ego
    - Mentira

2. En el video adjunto tienes una demo de la funcionalidad.

3. Define la línea de color a tu gusto
