1. Dado el siguiente objeto dom

<div><img src="https://picsum.photos/200/300" alt="foto random" title="foto aleatoria"><div>


2. Crea una función que reciba un objeto por parámetro y realice las siguientes acciones:
    - Añadir padding:40px al div
    - Añadir background rojo al div
    - Añadir borde 2px solid black al div
    - Cambiar el atributo 'title' de la imagen por "foto random" 
    - Definir display: none para la imagen

3. Extrae todas las acciones a funciones individuales

4. Cuando acabes avisa a mike