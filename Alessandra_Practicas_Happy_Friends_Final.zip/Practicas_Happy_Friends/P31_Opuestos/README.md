1. Trasladar a código la imagen desktop.png
2. Hacer que se convierta en mobile.png para tamaños inferiores a 960px