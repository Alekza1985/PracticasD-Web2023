1. Traslada a código los diseños adjuntos.
2. Realiza los media queries necesarios para que se vea bien en TODOS los formatos de pantalla.