const meses = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre",
];

const diasSemana = {
    lunes: "L",
    martes: "M",
    miercoles: "X",
    jueves: "J",
    viernes: "V",
    sabado: "S",
    domingo: "D",
};

document.body.style.background = "linear-gradient(30deg, #131fff 0%, #2d38fe 35%, #4e57ff 100%)";



// Creo un contenedor con el título y el contenedor para los meses
document.body.innerHTML = '<h1 style="text-align: center; font-family: Arial, Helvetica, sans-serif;font-size: 3rem;padding:10px; color: #ffffff">Calendario 2024</h1><div class="container"></div>';

// Capturo el contenedor
const container = document.querySelector('.container');

// Aplico estilo grid al contenedor
container.style.fontFamily = "Arial, Helvetica, sans-serif";
container.style.margin = "60px";
container.style.display = "grid";
container.style.gridTemplateColumns = "repeat(4, 1fr)";
container.style.border = "3px solid #000";
container.style.backgroundColor = "#ffffff";

// Recorro el array y en cada mes aplico una función (callback)
meses.forEach((mes) => {
    container.innerHTML += `<div class= "mes_${mes}" 
    style ="padding: 5px; border: 2px solid #000; text-align: center; text-transform: uppercase"><h3>${mes}</h3></div>`;

    // Capturamos mes
    const mesActual = document.querySelector('.mes_' + mes);
    const tituloMes = document.querySelector('.mes_' + mes + ' h3'); // El espacio es para que busque al hijo
    tituloMes.style.gridColumn = "span 7";

    // Estilos a mes
    mesActual.style.display = "grid";
    mesActual.style.gridTemplateColumns = "repeat(7, 1fr)";

    // Creo container de días
    mesActual.innerHTML += `<div class="dias_title_${mes}"></div>`;

    // Capturo header de días
    const diasSemanaHeading = document.querySelector('.dias_title_' + mes);

    // Ajusto maquetación
    diasSemanaHeading.style.gridColumn = "span 7";
    diasSemanaHeading.style.display = "grid";
    diasSemanaHeading.style.gridTemplateColumns = "repeat(7, 1fr)";

    // Pinto con un loop los días de la semana dentro del contenedor de días
    Object.values(diasSemana).forEach((dia) => {
        diasSemanaHeading.innerHTML += `<p style="font-weight:800">${dia}</p>`;
    });

    let dias = 31;

    if (mes == "Febrero") dias = 29;
    if (mes == "Abril" || mes == "Junio" || mes == "Septiembre" || mes == "Noviembre") dias = 30;

    for (let i = 1; i <= dias; i++) {
        mesActual.innerHTML += `<span>${i}</span>`;
    }
});
