# PRÁCTICA X - Position

1. posiciona la mujer en el centro exacto de la pantalla

2. Crea los chakras y alinéalos a lo loargo de la mujer en vertical.
    - Tendrás que crear los chakras en 'svg' en su **color exacto** con un programa de diseño vectorial tipo figma / illustrator.

3. Implementa que los chakras aumenten de tamaño cuando se les pase el ratón por encima y regresen a su tamaño original cuando el ratón se desplace fueras de ellos.

4. Crea elementos de audio en html y haz que suenen los chakras cuando se les pase el ratón por encima.

5. Implementa que cuando el ratón pase por encima de la mujer comience a girar la rueda posterior infinitamente.

6. Hazlo responsive.