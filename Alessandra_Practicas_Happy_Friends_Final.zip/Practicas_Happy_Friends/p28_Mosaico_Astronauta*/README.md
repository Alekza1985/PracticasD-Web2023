1. Crea el bello mosaico que se muestra en la imagen adjunta con css grid.
