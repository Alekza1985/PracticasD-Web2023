# P42 Gatetes

1. Navegar a https://apilist.fun/api/cats
2. Clicar en go to api docs
3. Navegar a authentication
4. Navegar al MAIN SITE (click en link main site)
5. Darse de alta para que nos envíen una api key
6. Concatenar la api en el final del string como dice la docu

7. Descargar JSON con 10 gatetes
8. Mostrar un grid con todos los gatetes
9. Enviar a un fichero de back jsonReceive.php los datos del gatete num.3
10. Que php nos reenvíe un mensaje " GATETE RECIBIDO!" Cuando reciba el gatete y que este se muestre debajo del grid de gatetes




# NOTAS
PORQUÉ API KEY?
- Controlar el aceso a la API
- Registrar el número de llamadas a la api
- Limitar el número llmaadas a la api por usuario