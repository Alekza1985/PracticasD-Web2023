1. Crea un sistema de combate con 3 personajes de bola de dragón que use el siguiente objeto para ver quién gana sobre quién
const personajes = {
            p0: {
                name: 'goku',
                force: '3'
            },
            p1: {
                name: 'vejeta',
                force: '2'
            }, 
            p2: {
                name: 'picollo',
                force: '1'
            } ,
        };



llamas el objeto y le pones wepp, asi cambias la imagen