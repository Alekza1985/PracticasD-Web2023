1. crea un cronómetro segundero con 3 botones: iniciar, parar y poner a cero
2. crea 2 slots en el que se mostrarán centésimas y segundos.
3. cuando las centésimas lleguen a 100 suma +1 segundos


