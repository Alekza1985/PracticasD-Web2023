            
        //declaro las constantes y variables
        const cronoButtons = document.querySelector('.crono__buttons');
        const cronoSeconds = document.querySelector('.crono__seconds');
        const cronoCentiSeconds = document.querySelector('.crono__miliseconds');
        let counterSeconds = 0;
        let counterCentiseconds = 0;
        let cronoInterval = ""; 
        let isRunning = false //al ser un "buleano", se coloca el el is delante

        //funciones
        function startCrono() {
            if (!isRunning){ 
                cronoInterval = setInterval(()=> {
                    counterCentiseconds++;

                    if (counterCentiseconds ===100){
                        counterSeconds += 1;
                        counterCentiseconds=0; 
                    }

                    showInHtml(counterSeconds, counterCentiseconds)
                }, 10);
            }

            isRunning = true;
        }

        function stopCrono(){
            clearInterval(cronoInterval);
            isRunning= false;
        }

        function zeroCrono() {
            counterSeconds =0;
            counterCentiseconds =0;
            showInHtml(0, 0);
            isRunning= false;
        }

        function showInHtml(seconds, centiseconds){
            cronoSeconds.innerHTML = seconds;
            cronoCentiSeconds.innerHTML = centiseconds;
        }


        //llamadas a funciones, eventos, y otros.
        cronoButtons.addEventListener('click', function(e){
            
            e.target.value === "start" && startCrono();
            e.target.value === "stop" && stopCrono();
            e.target.value === "zero" && zeroCrono();
        })
