# PRÁCTICA 22 - Form

1. Crea un formulario de Admisión para un Gimnasio

2. crea un input tipo text con un label 'nombre y apellidos'.

3. Crea 3 inputs tipo checkbox con sus correspondientes labels:
    - Mayor de 18
    - Sin problemas de corazón
    - En pleno uso de mis facultades mentales


4. Crea 3 input tipo radio button con un título: Sexo

    - radio button 1: Label Hombre
    - radio button 2: Label Mujer
    - radio button 2: Label Otro

5. Crea un selector con título "Elige tu deporte" y qeu tenga 3 opciones:

    - Crossfit
    - Spinning
    - Kung fu

6. crea un input tipo textarea con un label 'comentarios'.

7. Crea un input tipo "submit".

8. Crea un input tipo password que muestra/oculte los valores introducidos por el usuario al pulsar en el ojito.

9. Envía todo el formulario al archivo formreception.php y comprueba que se haya enviado correctamente


