const pwdInput = document.querySelector(".pwdInput");
const show = document.querySelector(".showPassword");
const hide = document.querySelector(".hidePassword");


show.addEventListener("click", () => {
  if (pwdInput.type === "password") {
      pwdInput.type = "text";
      show.style.visibility = "hidden";
      hide.style.visibility = "visible";
  } 
   });


hide.addEventListener("click", () => {
  if (pwdInput.type = "text") {
      pwdInput.type ="password";
      show.style.visibility = "visible";
      hide.style.visibility = "hidden";
  } 
  
  });