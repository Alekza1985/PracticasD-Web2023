// 1. Capturar elementos (cada uno de ellos elementos: TODOS. En este caso: el botón y la foto)

const rectanguloHome = document.querySelector ('#rectanguloHome')
const rectanguloSweet = document.querySelector ('#rectanguloSweet')
const rectanguloAbout = document.querySelector ('#rectanguloAbout')
const rectanguloMe = document.querySelector ('#rectanguloMe')

const circulo = document.querySelector ('#circulo')

const rectanguloLife = document.querySelector ('#rectanguloLife')
const rectanguloGood = document.querySelector ('#rectanguloGood')
const rectanguloContact = document.querySelector ('#rectanguloContact')
const rectanguloYou = document.querySelector ('#rectanguloYou')




// 2. Crear eventos de usuarios (en este caso el evento "onclick": el botón en este caso)
circulo.addEventListener ('click', cambiarColorRectangulos)



// 3. Crear funcion que sucederá al ejecutar el evento (En este caso cambiar la url de la foto)           
    let circuloclicCounter = 0

    function cambiarColorRectangulos () {

        if (circuloclicCounter==0) {     
        rectanguloHome.style.backgroundColor = "yellow";
        rectanguloAbout.style.backgroundColor = "yellow";
        rectanguloYou.style.backgroundColor = "yellow";
        rectanguloContact.style.backgroundColor = "yellow";
        rectanguloGood.style.backgroundColor = "yellow";
        rectanguloLife.style.backgroundColor = "yellow";
        rectanguloMe.style.backgroundColor = "yellow";
        rectanguloSweet.style.backgroundColor = "yellow";
    }
    circuloclicCounter = circuloclicCounter +1  


        if (circuloclicCounter==2) {
                
        rectanguloHome.style.backgroundColor = "white";
        rectanguloAbout.style.backgroundColor = "white";
        rectanguloYou.style.backgroundColor = "white";
        rectanguloContact.style.backgroundColor = "white";
        rectanguloGood.style.backgroundColor = "white";
        rectanguloLife.style.backgroundColor = "white";
        rectanguloMe.style.backgroundColor = "white";
        rectanguloSweet.style.backgroundColor = "white";

        circuloclicCounter = 0;  

    
        }
        
          
        }






